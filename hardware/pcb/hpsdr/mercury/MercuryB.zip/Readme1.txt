If there are any questions, please contact:

[ insert contact delatils here ]

This is a four (4) layer board.  
FR4
.062" thick


There are some important details on this fabrication.  See the enclosed PDF-format drawing for details.


The following files are included:

Readme.txt	This file
MERCURY.PDF	Drawing with important information on this fabrication.

MERCURY.BOT	Bottom layer
MERCURY.DRD	Drill drawing
MERCURY.GND	Ground plane
MERCURY.GTD	Design file
MERCURY.PWR	Power plane
MERCURY.SMB	Bottom solder mask
MERCURY.SMT	Top solder mask
MERCURY.SPB	Bottom Solder paste (not used in PCB fabrication)
MERCURY.SPT	Top Solder paste (not used in PCB fabrication)
MERCURY.SSB	Bottom silkscreen
MERCURY.SST	Top silkscreen
MERCURY.TOP	Top layer

MERCURY.DTS	Drill tape summary report
THRUHOLE.TAP	Drill file
INSERT.TXT	Component insertion data


Stack order:

Top silkscreen
Top solder mask
Top layer
Power plane
Ground plane
Bottom layer
Bottom solder mask
Bottom silkscreen

[end of file]

